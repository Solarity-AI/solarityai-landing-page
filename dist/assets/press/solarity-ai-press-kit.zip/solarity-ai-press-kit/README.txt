Solarity AI press kit

One line
Solarity AI builds AI self-improvement apps and the tools that let its small team ship them fast.

Short description
Solarity AI LLC, based in Irving, Texas, builds AI-powered self-improvement apps: Looks Max, IQ Max, Sleep Max, and Fitness Max (listed in the app stores as Only Fitness), all on iOS and Android. Building them shaped three web apps for teams that build mobile products: Engineering Max, Management Max, and Marketing Max. Founder: Ata Turhan.

Write the name as Solarity AI. Use the sun mark as supplied; do not recolor, stretch, or redraw it.
Fitness Max appears in the app stores as Only Fitness.

Source: https://solarityai.com/press/
